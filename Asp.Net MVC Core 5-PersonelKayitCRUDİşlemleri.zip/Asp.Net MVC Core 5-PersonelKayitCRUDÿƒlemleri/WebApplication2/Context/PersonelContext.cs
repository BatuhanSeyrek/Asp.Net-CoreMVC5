﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using Web.Models;

namespace Web.Context
{
    public class PersonelContext : DbContext
    {
        public PersonelContext(DbContextOptions<PersonelContext> options) : base(options)
        {
        }
        public DbSet<PersonelKayit> PersonelKayit { get; set; }
       public DbSet<Ulkeler_Sehirler> Ulkeler_Sehirler { get; set; }
       public DbSet<MedyaKutuphanesi> MedyaKutuphanesi { get; set; }

    }
}

