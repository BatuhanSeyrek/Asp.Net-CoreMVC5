﻿using System.ComponentModel.DataAnnotations;

namespace Web.Models
{
    public class MedyaKutuphanesi
    {
        [Key]
        public int TabloID  { get; set; }
        public string MedyaAL { get; set; }
        public string MedyaURL { get; set; }
    }
}
