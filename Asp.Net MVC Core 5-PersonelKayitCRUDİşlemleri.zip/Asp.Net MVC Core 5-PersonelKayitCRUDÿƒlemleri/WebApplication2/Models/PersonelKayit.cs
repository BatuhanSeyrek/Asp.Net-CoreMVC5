﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Web.Models
{
    public class PersonelKayit
    {
        [Key]
        public int Id { get; set; }
        public string Ad { get; set; }
        public string Soyad { get; set; }
        public DateTime? DogumTarihi { get; set; }
        public bool Cinsiyet { get; set; }
        public string Ulke { get; set; }
        public string Sehir { get; set; }
        public string Aciklama { get; set; }
        public bool Aktif { get; set; } = true;
        public int MedyaId { get; set; }

    }
}
