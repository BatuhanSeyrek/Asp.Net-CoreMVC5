﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Web.Models
{
    public class Ulkeler_Sehirler
    {
        [Key]
        public int Id { get; set; }
        public string Ulke_Sehir { get; set; }
        public int UstId { get; set; }
    }
}
