﻿using System;
using System.Collections.Generic;

namespace Web.Models
{
    public class PersonelVM
    {
        public List<PersonelKayit> Personel { get; set; }
        public List<MedyaKutuphanesi> Medya { get; set; }
    }
}
