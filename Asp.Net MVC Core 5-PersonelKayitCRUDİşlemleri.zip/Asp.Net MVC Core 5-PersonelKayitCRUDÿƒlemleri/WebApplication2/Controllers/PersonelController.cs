﻿using Elasticsearch.Net;
using Microsoft.AspNetCore.Hosting.Server;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Nest;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Web.Context;
using Web.Models;

namespace WebApplication2.Controllers
{
    public class PersonelController : Controller
    {
        private readonly ILogger<PersonelController> _logger;
        private readonly PersonelContext _personelContext;

        public PersonelController(ILogger<PersonelController> logger, PersonelContext personelContext)
        {
            _logger = logger;
            _personelContext = personelContext;
        }
        [Route("/Personel/AjaxUpload/")]
        [HttpPost]
        public int AjaxUpload(IList<IFormFile> files)
        {
            var path = "";
            var fileName = "";
            foreach (var formFile in files)
            {
                if (formFile.Length > 0)
                {
                    path = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "MedyaKutuphanesi", formFile.FileName);
                    var filePath = Path.GetTempFileName();
                    fileName = formFile.FileName;

                    string id = Guid.NewGuid().ToString();
                    //string uniquePath = id + "_" + path;

                    //string islemleri yaparak doğru pathi buldum
                    string[] dizi = path.Split('\\');
                    dizi[dizi.Length - 1] = id + "_" + dizi[dizi.Length - 1];
                    string uniquePath = string.Join("\\", dizi);
                    int uzunluk = dizi.Length - 7;
                    string[] yeniDizi = new string[uzunluk];
                    Array.Copy(dizi, 7, yeniDizi, 0, uzunluk);
                    string newPath = string.Join("\\", yeniDizi);

                    using (var stream = System.IO.File.Create(uniquePath))
                    {
                        formFile.CopyTo(stream);
                    }

                    var medyaKutuphanesiKaydet = new MedyaKutuphanesi()
                    {
                        MedyaAL =  fileName,
                        MedyaURL = newPath,
                    };
                    _personelContext.MedyaKutuphanesi.Add(medyaKutuphanesiKaydet);
                    _personelContext.SaveChanges();

                    var lastAddedEntity = _personelContext.MedyaKutuphanesi.OrderByDescending(e => e.TabloID).FirstOrDefault();
                    int lastid = lastAddedEntity.TabloID;


                    return lastid;
                }
            }
            return 0;
        }
        public IActionResult PersonelListele()
        {
            return View();
        }
        [Route("/Personel/PersonelEkle/")]
        [HttpPost]
        public bool PersonelEkle(PersonelKayit personel)
        {
            var kaydet = new PersonelKayit()
            {
                Id=personel.Id,
                Ad = personel.Ad,
                Soyad = personel.Soyad,
                DogumTarihi = personel.DogumTarihi,
                Cinsiyet = personel.Cinsiyet,
                Ulke = personel.Ulke,
                Sehir = personel.Sehir,
                Aciklama = personel.Aciklama,
                MedyaId = personel.MedyaId
        };

            _personelContext.PersonelKayit.Add(kaydet);
            _personelContext.SaveChanges();
            return true;
        }
        [Route("/Personel/PersonelleriListele/")]
        [HttpGet]
        public PersonelVM PersonelleriListele()
        {
            

            var personeller = _personelContext.PersonelKayit.Where(x => x.Aktif == true).ToList();
            List<PersonelKayit> PersonelList = new List<PersonelKayit>();
            foreach (var personel in personeller)
            {
                PersonelList.Add(personel);
            }

            var medyalar = _personelContext.MedyaKutuphanesi.ToList();
            List<MedyaKutuphanesi> Medyalist = new List<MedyaKutuphanesi>();
            foreach (var medya in medyalar)
            {
                Medyalist.Add(medya);
            }

            PersonelVM personelvm = new PersonelVM();
            personelvm.Personel = PersonelList;
            personelvm.Medya = Medyalist;

            return personelvm;
        }
        [Route("/Personel/UlkeGetir/")]
        [HttpGet]
        public List<Ulkeler_Sehirler> UlkeGetir()
        {
            var deneme = _personelContext.Ulkeler_Sehirler.Where(x => x.UstId == 0 ).ToList();

            List<Ulkeler_Sehirler> ulke_sehirList = new List<Ulkeler_Sehirler>();

            foreach (var ulke_sehir in deneme)
            {
                ulke_sehirList.Add(ulke_sehir);
            }
            return ulke_sehirList.ToList();

        }

        [Route("/Personel/SehirGetir/{id}")]
        [HttpGet]
        public List<Ulkeler_Sehirler> SehirGetir(int id)
        {
            var deneme = _personelContext.Ulkeler_Sehirler.Where(x => x.UstId == id ).ToList();

            List<Ulkeler_Sehirler> SehirList = new List<Ulkeler_Sehirler>();
            foreach (var sehirler in deneme)
            {
                SehirList.Add(sehirler);
             
            }
            return SehirList.ToList();
        }

        [Route("/Personel/TumUlkeSehirGetir")]
        [HttpGet]
        public List<Ulkeler_Sehirler> TumUlkeSehirGetir()
        {
            List<Ulkeler_Sehirler> deneme = _personelContext.Ulkeler_Sehirler.ToList();  
            
            return deneme.ToList();
        }
      
        public IActionResult PersonelEkleYeni(int id)
        {
            return View();
        }
        [Route("/Personel/PersonelGuncelle/{id}")]
        [HttpGet]
        public PersonelVM PersonelGuncelle(int id)
        {
            var personel = _personelContext.PersonelKayit.Where(x => x.Id == id).ToList();
            var medya = _personelContext.MedyaKutuphanesi.Where(x => x.TabloID == personel[0].MedyaId).ToList();

            PersonelVM personelVM = new PersonelVM();
            personelVM.Personel = personel;
            personelVM.Medya = medya;
            return personelVM;
        }
       
        [HttpPost]
        public bool PersonelUpdate(PersonelKayit personel)

        {
            var personeleski = _personelContext.PersonelKayit.Where(x => x.Id == personel.Id).FirstOrDefault();
            personeleski.Ad = personel.Ad;
            personeleski.Soyad = personel.Soyad;
            personeleski.DogumTarihi = personel.DogumTarihi;
            personeleski.Cinsiyet = personel.Cinsiyet;
            personeleski.Ulke = personel.Ulke;
            personeleski.Sehir = personel.Sehir;
            personeleski.Aciklama = personel.Aciklama;
            personeleski.MedyaId = personel.MedyaId;
          
            _personelContext.PersonelKayit.Update(personeleski);
            _personelContext.SaveChanges();
            return true;
        }
        [Route("/Personel/SilPersonel/{id}")]
        [HttpGet]
        public bool SilPersonel(int id)
        {
            var personel = _personelContext.PersonelKayit.FirstOrDefault(x => x.Id == id);
            personel.Aktif = false;
            _personelContext.SaveChanges();

            return true;
        }
        [Route("/Personel/DeletePhoto/{id}")]
        [HttpGet]
        public PersonelKayit DeletePhoto(int id)
        {
            
            PersonelKayit personel = new PersonelKayit();
            personel = _personelContext.PersonelKayit.Where(x=>x.Id==id).ToList()[0];

            personel.MedyaId = 0;
            _personelContext.SaveChanges();
            return personel;
        }
    } 
  }  
