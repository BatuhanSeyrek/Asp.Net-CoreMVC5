﻿var PersonelModel = {};
var medyaIdForUpdate = "";
var personel1 = {};
$(document).ready(function () {
    var url = window.location.pathname;
    var URLSplitlenmis = url.split("/");
    var id = URLSplitlenmis[3];
    PersonelGuncelle(id);
    UlkeGetir();
});
function PersonelGuncelle(id) {

    $.ajax({
        url: '/Personel/PersonelGuncelle/' + id,
        type: 'GET',
        dataType: "json",
        data: null,
        async: false,

        success: function (result) {
            console.log(result);
            PersonelModel = result.personel[0];
            var medya = result.medya[0];
            PersonelBilgileriSayfayaBas(medya);
        },
        error: function (xhr, status, error) {
            console.log();
            alert("Hata : " + error);
        }
    });
}
function IdyeGoreKategoriGetir(id) {
    var PersonelIsim = null;
    $.ajax({
        url: '/Personel/PersonelGuncelle/' + id,
        type: 'GET',
        dataType: "json",
        data: null,
        async: false,

        success: function (result) {
            personel = result; // Sonucu tipIsim değişkenine atayın
        },
        error: function (xhr, status, error) {
            console.log();
            alert("Hata : " + error);
        }
    });
    return personel; // Sonucu döndürün
}

function PersonelBilgileriSayfayaBas(medya) {
    medyaIdForUpdate = PersonelModel.medyaId;
    $("#resimSilme").val(PersonelModel.id);

    $("#Ad").val(PersonelModel.ad);
    $('#Soyad').val(PersonelModel.soyad);
    $('#DogumTarihi').val(PersonelModel.dogumTarihi.split('T')[0]);
    console.log(PersonelModel.cinsiyet);
    if (PersonelModel.cinsiyet == true) {
        const defaultOption = document.querySelector('#CinsiyetK');
        if (defaultOption) {
            defaultOption.checked = true;
        }
    }
    else {
        const defaultOption = document.querySelector('#CinsiyetE');
        if (defaultOption) {
            defaultOption.checked = true;
        }
    }
    $('#cinsiyet').val(PersonelModel.cinsiyet);
    $('#Ulke').val(PersonelModel.ulke).change();

    //$('#Sehir').val(PersonelModel.sehir).change();
    $('#Aciklama').val(PersonelModel.aciklama);

    if (medya != null) {
        var medyasplited = medya.medyaURL.split("\\");

        //$("#MedyaAL").attr("src", "/MedyaKutuphanesi/" + medyasplited[medyasplited.length - 1]);
        $("#MedyaURL").attr("src", "");
        var url = "/MedyaKutuphanesi/" + medyasplited[(medyasplited.length - 1)];
        $("#MedyaURL").attr("src", url);

        var fileName = medya.medyaAL; // Dosya adı
        var filePath = medya.medyaURL; // Dosya yolu


        var splited = filePath.split("\\");
        fetch("/wwwroot/MedyaKutuphanesi/" + splited[splited.length - 1])
            .then(result => result.blob())
            .then(blob => {
                // Blob nesnesini kullanarak File nesnesi oluşturma
                const file = new File([blob], fileName, {
                    type: blob.type,
                    lastModified: new Date()
                });
                console.log(file)
                // Oluşturulan File nesnesini kullanabilirsiniz
                const fileInput = document.getElementById('MedyaAL');
                //fileInput.files = [file];

                const dataTransfer = new DataTransfer();
                dataTransfer.items.add(file);
                fileInput.files = dataTransfer.files;
            })
            .catch(error => {
                console.error(error);
            });

    };
}
function DeletePhoto() {
    var src = $("#MedyaURL").attr("src")
    if (src != undefined) {
        var access = confirm("Fotoğrafı Silmek İstediğinize Emin Misiniz");
        if (access) {
            var id = $("#resimSilme").val();
            $.ajax({
                url: '/Personel/DeletePhoto/' + id,
                type: 'GET',
                dataType: 'json',
                async: false,
                success: function (result) {
                    if (result != null) {
                        $("#MedyaURL").attr("src", "");
                        $('#MedyaAL').val("");
                        personel1 = result;
                    }
                }
            })
        }
    }
}