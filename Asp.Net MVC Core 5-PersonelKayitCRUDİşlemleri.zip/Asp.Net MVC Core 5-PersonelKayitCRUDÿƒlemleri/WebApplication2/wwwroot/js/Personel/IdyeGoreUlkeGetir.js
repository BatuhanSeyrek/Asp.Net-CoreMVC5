﻿//function IdyeGoreKategoriGetir(id) {
//    var PersonelIsim = null; 
//    $.ajax({
//        url: '/Home/IdyeGorePersonelGetir/' + id,
//        type: 'GET',
//        dataType: "json",
//        data: null,
//        async: false,

//        success: function (result) {
//            personel = result; // Sonucu tipIsim değişkenine atayın
//        },
//        error: function (xhr, status, error) {
//            console.log();
//            alert("Hata : " + error);
//        }
//    });
//    return personel; // Sonucu döndürün
//}
