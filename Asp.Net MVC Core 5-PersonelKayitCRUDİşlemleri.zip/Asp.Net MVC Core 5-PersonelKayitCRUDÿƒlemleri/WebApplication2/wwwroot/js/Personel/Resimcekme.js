﻿var degisim = {}
degisim.okey = false;
$(document).ready(function () {
    $("#MedyaAL").change(function (event) {
       
        let secilenResim = document.getElementById('MedyaURL');
        const dosya = this.files[0];
        if (dosya) {
            degisim.okey = true;
            const dosyaURL = URL.createObjectURL(dosya);
            secilenResim.src = dosyaURL;
            secilenResim.style.display = 'block';
        }
        
        else {
            secilenResim.style.display = 'none';
            secilenResim.src = '#';
        }

    });
});