﻿//$(document).ready(function () {
//   /* PersonelleriGetir();*/
PersonelKayit = {};

//});

//$(function () {
//    console.log("ready!");
//});


function PersonelEkle() {
    

    PersonelKayit['Ad'] = $('#Ad').val();
    PersonelKayit['Soyad'] = $('#Soyad').val();
    PersonelKayit['DogumTarihi'] = $('#DogumTarihi').val();
    PersonelKayit['Ulke'] = $('#Ulke').val();
    PersonelKayit['Sehir'] = $('#Sehir').val();
    PersonelKayit['Aciklama'] = $('#Aciklama').val();
    PersonelKayit['Cinsiyet'] = $("#cinsiyet input[type='radio']:checked").val();
    PersonelKayit['MedyaId'] = uploadFiles();

    

    
    var model = PersonelKayit;
    if (model.MedyaId == 0) {
        alert("Medyyayi Seçiniz...")
    }
    else {
        $.ajax({
            url: '/Personel/PersonelEkle/',
            type: 'POST',
            dataType: "json",
            data: model,
            async: false,

            success: function (result) {
                console.log(result);
                alert("ekleme işlemi başarılı");
                window.location.href = '/Category/List/';
            },
            error: function (xhr, status, error) {
                console.log();
                alert("Hata : " + error);
            }
        });
    }
}
function uploadFiles() {


    var medyaId1 = null;
    var input = document.querySelector("#MedyaAL");
    var files = input.files; //get files
    var formData = new FormData(); //create form

    for (var i = 0; i != files.length; i++) {
        formData.append("files", files[i]); //loop through all files and append
    }
    $.ajax(
        {
            url: "/Personel/AjaxUpload/",
            data: formData, // send it as formData
            processData: false,
            contentType: false,
            type: "POST", //type is post as we will need to post files
            async: false,
            success: function (result) {
                console.log(result);
                medyaId1 = result;
            },
            error: function (xhr, status, error) {
                console.log();
                alert("Hata : " + error);
            }
        }
    );

    return medyaId1;
}