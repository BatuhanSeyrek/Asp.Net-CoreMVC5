﻿$(document).ready(function () {
    $('#Tablo').DataTable();
});