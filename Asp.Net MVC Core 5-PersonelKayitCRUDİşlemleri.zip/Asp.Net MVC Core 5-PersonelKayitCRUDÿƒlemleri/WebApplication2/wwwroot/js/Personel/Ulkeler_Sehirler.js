﻿var ulke_sehir = "";
var sehir = "";
var sehirler = [];
$(document).ready(function () {
    Ulkeler_SehirlerGetir();
    Hazirla();
});

function Ulkeler_SehirlerGetir() {
    $.ajax({
        url: '/Personel/UlkeGetir/',
        type: 'GET',
        dataType: "json",
        data: null,
        async: false,

        success: function (result) {
            console.log(result);


            ulke_sehir += "<option value='0'>Seçiniz</option>"
            for (var i of result) {
                ulke_sehir += "<option value='" + i.id + "'>" + i.ulke_Sehir + "</option>";
            }
            $("#Ulke").html(ulke_sehir);

        },
        error: function (xhr, status, error) {
            console.log();
            alert("Hata : " + error);
        }
    });
}
function Hazirla() {
    $("#Ulke").change(function () {
        var id = $(this).val();
        $.ajax({
            url: '/Personel/SehirGetir/' + id,
            type: 'GET',
            dataType: "json",
            data: null,
            async: false,

            success: function (result) {
                sehirler = result;
                console.log(sehirler);

                sehir = "";

                sehir += "<option class='x' value='0'>Seçiniz</option>"
                for (var i of sehirler) {
                    sehir += "<option class='x' value='" + i.id + "'>" + i.ulke_Sehir + "</option>";
                }

                $("#Sehir").html(sehir);
                $("#Sehir").val(PersonelModel.sehir);
            }
        })
    })
}

/*function SehirGetir(id) {
    $.ajax({
        url: '/Personel/SehirGetir/' + id,
        type: 'GET',
        dataType: "json",
        data: null,
        async: false,

        success: function (result) {
            sehirler = result;
            console.log(sehirler);

            sehir = "";
             
            sehir += "<option class='x' value='0'>Seçiniz</option>"
            for (var i of sehirler) {
                sehir += "<option class='x' value='" + i.id + "'>" + i.ulke_Sehir + "</option>";                          
            }

            $("#Sehir").html(sehir);
            //$("#Sehir").val(myapp.sehir);
          
        },
        error: function (xhr, status, error) {
            console.log();
            alert("Hata : " + error);
        }
    });
}*/


