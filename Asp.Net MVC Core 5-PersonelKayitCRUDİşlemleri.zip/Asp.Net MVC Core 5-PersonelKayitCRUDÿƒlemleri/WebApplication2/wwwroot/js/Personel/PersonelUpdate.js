﻿function PersonelBilgileriniSayfadanCek() {
    PersonelModel2 = {};
    var url = window.location.pathname;
    var URLSplitlenmis = url.split("/");
    var id = URLSplitlenmis[3];
    PersonelModel2["Id"] = id;

    var mediaid = medyaIdForUpdate;


    PersonelModel2['Ad'] = $('#Ad').val();
    PersonelModel2['Soyad'] = $('#Soyad').val();
    PersonelModel2['DogumTarihi'] = $('#DogumTarihi').val();
    PersonelModel2['Ulke'] = $('#Ulke').val();
    PersonelModel2['Sehir'] = $('#Sehir').val();
    PersonelModel2['Aciklama'] = $('#Aciklama').val();
    PersonelModel2['Cinsiyet'] = $('#cinsiyet').val();
    if (degisim.okey == true) {
        mediaid = uploadFiles1();
        PersonelModel2['MedyaId'] = mediaid
    }
    else if (personel1.medyaId == 0) {
        /*  PersonelModel2['medyaId'] = mediaid*/
        PersonelModel2['MedyaId'] = 0;
    }
    else {
        PersonelModel2['MedyaId'] = mediaid;
    }
   



    console.log(PersonelModel2);
}

function PersonelUpdate() {
    PersonelBilgileriniSayfadanCek();
    var model = PersonelModel2;
    $.ajax({
        url: '/Personel/PersonelUpdate/',
        type: 'POST',
        dataType: "json",
        data: model,
        async: false,

        success: function (result) {
            alert("basarili");
            window.location.assign('/Personel/PersonelleriListele/');
        },
        error: function (xhr, status, error) {
            console.log();
            alert("Hata : " + error);
        }
    });
}
function uploadFiles1() {


    var medyaId1 = null;
    var input = document.querySelector("#MedyaAL");
    var files = input.files; //get files
    var formData = new FormData(); //create form

    for (var i = 0; i != files.length; i++) {
        formData.append("files", files[i]); //loop through all files and append
    }
    $.ajax(
        {
            url: "/Personel/AjaxUpload/",
            data: formData, // send it as formData
            processData: false,
            contentType: false,
            type: "POST", //type is post as we will need to post files
            async: false,
            success: function (result) {
                console.log(result);
                medyaId1 = result;
            },
            error: function (xhr, status, error) {
                console.log();
                alert("Hata : " + error);
            }
        }
    );

    return medyaId1;
}