﻿function SilPersonel(id) {
    $.ajax({
        url: '/Personel/SilPersonel/' + id,
        type: 'GET',
        dataType: "json",
        data: null,
        async: false,
        success: function (result) {
            console.log(result);
            alert("Silme işlemi başarılı");
            location.reload();
        },
        error: function (xhr, status, error) {
            console.log();
            alert("Hata : " + error);
        }
    });
}
function SilmeChecker(id) {
    var result = confirm('Emin misiniz ?');
    if (result == false) {
        event.preventDefault();
    }
    else {
        SilPersonel(id);
    }
}