﻿var tumUlkeSehirler = [];

$(document).ready(function () {

    TumUlkeSehileriGetir();
    PersonelleriListele();
    $('#Tablo').DataTable();
});

function PersonelleriListele() {
    $.ajax({
        url: '/Personel/PersonelleriListele/',
        type: 'GET',
        dataType: "json",
        data: null,
        async: false,

        success: function (result) {
            var personeller = result.personel;
            var medya = result.medya;
            console.log(personeller);

            var personel = ""; // Değişkeni tanımlayın

            for (var i = 0; i < personeller.length; i++) {
                var id = personeller[i].id;
                var Ad = personeller[i].ad;
                var Soyad = personeller[i].soyad;


                var year = personeller[i].dogumTarihi.substring(0, 4);
                var mounth = personeller[i].dogumTarihi.substring(5, 7);
                var day = personeller[i].dogumTarihi.substring(8, 10);

                var Ulke = tumUlkeSehirler.find(x => x.id == personeller[i].ulke).ulke_Sehir;
                var Sehir = tumUlkeSehirler.find(x => x.id == personeller[i].sehir).ulke_Sehir;
                var Aciklama = personeller[i].aciklama;
                var Cinsiyet;
                if (personeller[i].cinsiyet == true) Cinsiyet = "Erkek";
                else Cinsiyet = "Kadın";

                var newsrc;
                if (personeller[i].medyaId == 0) {
                    newsrc = "";
                } else {
                    var src = medya.find(x => x.tabloID == personeller[i].medyaId).medyaURL.split("\\");
                    newsrc = "/MedyaKutuphanesi/" + src[(src.length - 1)];
                }
                //var src = medya.find(x => x.tabloID == personeller[i].medyaId).medyaURL.split("\\");
                //newsrc = "/MedyaKutuphanesi/" + src[(src.length - 1)];

                personel += `<tr>
                
                    <td>${Ad}</td>
                    <td>${Soyad}</td>
                    <td><img src="${newsrc}" alt="Küçük Resim" style="width: 80px; height: 80px; "></td>
                    <td>${day + "." + mounth + "." + year}</td>
                    <td>${Cinsiyet}</td>
                    <td>${Ulke}</td>
                    <td>${Sehir}</td>
                    <td>${Aciklama}</td>
                    <td>
                        <button class="btn btn-success" id="${id}" onclick="PersonelGuncelleSayfasinaGit(${id})">Düzenle</button>
                        <button id="${id}" onclick="SilmeChecker(${id})" class="btn btn-danger">Sil</button>
                    </td>
                 
                </tr>`;
            }
            $("#x").html(personel);
            //for (var i = 0; i < personeller.length; i++) {
            //    var medya = KapakMedyaIdyeGoreMedyaKutuphanesindenGetir(personeller[i].MedyaId);
            //    var medyaUrl = ResmiYukle2(i, MedyaKutuphanesi.medyaUrl);
            //    var gosterilecekResim = document.getElementById('MedyaAL' + i);
            //    gosterilecekResim.src = medyaUrl;
            //}

        },
        error: function (xhr, status, error) {
            console.log();
            alert("Hata : " + error);
        }
    });
}

function TumUlkeSehileriGetir() {
    $.ajax({
        url: '/Personel/TumUlkeSehirGetir/',
        type: 'GET',
        dataType: "json",
        data: null,
        async: false,

        success: function (result) {

            tumUlkeSehirler = result;

        },
        error: function (xhr, status, error) {
            console.log();
            alert("Hata : " + error);
        }
    });
}
function PersonelGuncelleSayfasinaGit(id) {
    window.location.href = '/Personel/PersonelEkleYeni/' + id;
}

